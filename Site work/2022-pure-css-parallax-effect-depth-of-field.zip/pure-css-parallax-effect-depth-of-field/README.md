# Pure CSS Parallax Effect (Depth of field)

A Pen created on CodePen.io. Original URL: [https://codepen.io/FlyC/pen/abGLyL](https://codepen.io/FlyC/pen/abGLyL).

use pure css create parallax effect with depth of field.  
and a little bit pop-up photo browser.

image source: pixiv.net